# PrintShop V2.2 規格管理修正版

本版依 Business_Rules_Final_v2.md 修正：

- 基礎規格：品項／材質／尺寸／單位／後加工
- 品項可關聯其適用材質／尺寸／單位／後加工
- 常用規格改為完整規格組合
- 常用規格只用於快速新增／快速帶入
- 後加工支援多選
- 首頁移除常用規格統計卡
- 報價頁可使用基礎品項，並依品項載入關聯規格
- 報價頁的常用規格搜尋改讀 quick_specs
- Business_Rules.md 已更新為最新規格

啟動：
```bash
python -m pip install -r requirements.txt
python -m app.main
```
