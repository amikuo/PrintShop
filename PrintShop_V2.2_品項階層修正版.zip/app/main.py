
from __future__ import annotations

import json
from datetime import datetime
from typing import Any

from flask import Flask, abort, flash, jsonify, redirect, render_template, request, url_for

from .database import (
    ORDER_STATUSES,
    PROJECT_STATUSES,
    QUOTE_STATUSES,
    connect,
    count_tables,
    create_order_from_payload,
    create_quote_from_payload,
    convert_quote_to_order,
    display_date,
    init_database,
    list_finishing_options,
    order_to_payload,
    quote_to_payload,
    refresh_expired_quotes,
    row_dict,
    rows_dict,
    search_customers,
    search_order_items,
    search_projects,
    search_spec_presets,
    today_key,
)

app = Flask(__name__)
app.secret_key = "printshop-v2.2-secret"


def db():
    return connect()


def parse_payload() -> dict[str, Any]:
    raw = request.form.get("payload_json", "").strip()
    if not raw:
        return {}
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return {}


def get_stats():
    conn = db()
    refresh_expired_quotes(conn)
    conn.commit()
    stats = {
        "unfulfilled": conn.execute(
            "SELECT COUNT(*) AS c FROM orders WHERE status IN ('設計中','印製中','待取貨')"
        ).fetchone()["c"],
        "designing": conn.execute(
            "SELECT COUNT(*) AS c FROM orders WHERE status = '設計中'"
        ).fetchone()["c"],
        "printing": conn.execute(
            "SELECT COUNT(*) AS c FROM orders WHERE status = '印製中'"
        ).fetchone()["c"],
        "pickup": conn.execute(
            "SELECT COUNT(*) AS c FROM orders WHERE status = '待取貨'"
        ).fetchone()["c"],
    }
    conn.close()
    return stats


@app.template_filter("money")
def money(value):
    try:
        return f"{float(value):,.0f}"
    except Exception:
        return "0"


@app.template_filter("display_date")
def display_date_filter(value):
    return display_date(value)


@app.context_processor
def inject_globals():
    return {
        "customer_categories": ["一般", "學校", "政府", "公司", "宗親會"],
        "quote_statuses": QUOTE_STATUSES,
        "order_statuses": ORDER_STATUSES,
        "project_statuses": PROJECT_STATUSES,
    }


@app.route("/")
def index():
    conn = db()
    refresh_expired_quotes(conn)
    conn.commit()
    stats = get_stats()

    recent_entries = conn.execute(
        """
        SELECT *
        FROM (
            SELECT
                'quote' AS record_type,
                q.id AS record_id,
                q.quote_number AS document_number,
                c.name AS customer_name,
                p.project_name AS project_name,
                q.status AS status,
                q.created_at AS created_at
            FROM quotes q
            JOIN customers c ON c.id = q.customer_id
            LEFT JOIN projects p ON p.id = q.project_id
            WHERE NOT EXISTS (
                SELECT 1 FROM orders o WHERE o.quote_id = q.id
            )

            UNION ALL

            SELECT
                'order' AS record_type,
                o.id AS record_id,
                o.order_number AS document_number,
                c.name AS customer_name,
                p.project_name AS project_name,
                o.status AS status,
                o.created_at AS created_at
            FROM orders o
            JOIN customers c ON c.id = o.customer_id
            LEFT JOIN projects p ON p.id = o.project_id
        )
        ORDER BY created_at DESC, record_id DESC
        LIMIT 12
        """
    ).fetchall()

    conn.close()
    return render_template(
        "index.html",
        stats=stats,
        recent_entries=recent_entries,
    )


# ---------------- Customers ----------------

@app.route("/customers")
def customers_list():
    q = request.args.get("q", "").strip()
    conn = db()
    if q:
        rows = conn.execute(
            """
            SELECT *
            FROM customers
            WHERE is_active = 1
              AND (
                name LIKE ? OR contact_person LIKE ? OR tax_id LIKE ? OR phone LIKE ? OR email LIKE ?
              )
            ORDER BY name
            """,
            (f"%{q}%", f"%{q}%", f"%{q}%", f"%{q}%", f"%{q}%"),
        ).fetchall()
    else:
        rows = conn.execute("SELECT * FROM customers WHERE is_active = 1 ORDER BY id DESC").fetchall()
    conn.close()
    return render_template("customers/list.html", customers=rows, q=q)


@app.route("/customers/new", methods=["GET", "POST"])
def customers_new():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        if not name:
            flash("客戶名稱不能空白。")
            return redirect(url_for("customers_new"))
        conn = db()
        cur = conn.execute(
            """
            INSERT INTO customers (name, contact_person, tax_id, phone, email, category, note)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                name,
                request.form.get("contact_person", "").strip(),
                request.form.get("tax_id", "").strip(),
                request.form.get("phone", "").strip(),
                request.form.get("email", "").strip(),
                request.form.get("category", "一般"),
                request.form.get("note", "").strip(),
            ),
        )
        conn.commit()
        cid = int(cur.lastrowid)
        conn.close()
        flash("客戶已建立。")
        return redirect(url_for("customers_edit", customer_id=cid))
    return render_template("customers/form.html", customer=None)


@app.route("/customers/<int:customer_id>/edit", methods=["GET", "POST"])
def customers_edit(customer_id):
    conn = db()
    customer = conn.execute("SELECT * FROM customers WHERE id = ?", (customer_id,)).fetchone()
    if not customer:
        conn.close()
        abort(404)
    if request.method == "POST":
        conn.execute(
            """
            UPDATE customers
               SET name = ?,
                   contact_person = ?,
                   tax_id = ?,
                   phone = ?,
                   email = ?,
                   category = ?,
                   note = ?,
                   updated_at = CURRENT_TIMESTAMP
             WHERE id = ?
            """,
            (
                request.form.get("name", "").strip(),
                request.form.get("contact_person", "").strip(),
                request.form.get("tax_id", "").strip(),
                request.form.get("phone", "").strip(),
                request.form.get("email", "").strip(),
                request.form.get("category", "一般"),
                request.form.get("note", "").strip(),
                customer_id,
            ),
        )
        conn.commit()
        conn.close()
        flash("客戶資料已更新。")
        return redirect(url_for("customers_list"))
    conn.close()
    return render_template("customers/form.html", customer=customer)


@app.route("/api/customers/search")
def api_customers_search():
    q = request.args.get("q", "").strip()
    conn = db()
    rows = search_customers(conn, q, limit=10) if q else []
    conn.close()
    return jsonify(rows)


# ---------------- Specifications ----------------

SPEC_TABLES = {
    "products": "products",
    "materials": "materials",
    "sizes": "sizes",
    "units": "units",
    "finishings": "finishing_options",
}


@app.route("/specs")
def specs_list():
    conn = db()
    products = conn.execute("SELECT * FROM products ORDER BY is_active DESC, name").fetchall()
    materials = conn.execute("SELECT * FROM materials ORDER BY is_active DESC, name").fetchall()
    sizes = conn.execute("SELECT * FROM sizes ORDER BY is_active DESC, name").fetchall()
    units = conn.execute("SELECT * FROM units ORDER BY is_active DESC, name").fetchall()
    finishings = conn.execute(
        "SELECT * FROM finishing_options ORDER BY is_active DESC, sort_order, name"
    ).fetchall()

    quick_specs = conn.execute("""
        SELECT qs.*, p.name AS product_name, m.name AS material_name,
               s.name AS size_name, u.name AS unit_name,
               COALESCE((
                   SELECT GROUP_CONCAT(fo.name, '、')
                   FROM quick_spec_finishings qsf
                   JOIN finishing_options fo ON fo.id=qsf.finishing_id
                   WHERE qsf.quick_spec_id=qs.id
               ), '') AS finishing_names
        FROM quick_specs qs
        JOIN products p ON p.id=qs.product_id
        LEFT JOIN materials m ON m.id=qs.material_id
        LEFT JOIN sizes s ON s.id=qs.size_id
        LEFT JOIN units u ON u.id=qs.unit_id
        ORDER BY qs.is_active DESC, qs.id DESC
    """).fetchall()

    relation_map = {}
    for p in products:
        pid = int(p["id"])
        relation_map[pid] = {
            "materials": [int(r["material_id"]) for r in conn.execute(
                "SELECT material_id FROM product_materials WHERE product_id=?", (pid,)
            ).fetchall()],
            "sizes": [int(r["size_id"]) for r in conn.execute(
                "SELECT size_id FROM product_sizes WHERE product_id=?", (pid,)
            ).fetchall()],
            "units": [int(r["unit_id"]) for r in conn.execute(
                "SELECT unit_id FROM product_units WHERE product_id=?", (pid,)
            ).fetchall()],
            "finishings": [int(r["finishing_id"]) for r in conn.execute(
                "SELECT finishing_id FROM product_finishings WHERE product_id=?", (pid,)
            ).fetchall()],
        }

    conn.close()
    return render_template(
        "products/list.html",
        products=products,
        materials=materials,
        sizes=sizes,
        units=units,
        finishings=finishings,
        quick_specs=quick_specs,
        relation_map=relation_map,
    )


@app.route("/specs/base/<kind>/new", methods=["POST"])
def specs_base_new(kind):
    table = SPEC_TABLES.get(kind)
    if not table:
        abort(404)

    name = request.form.get("name", "").strip()
    if not name:
        flash("名稱不能空白。")
        return redirect(url_for("specs_list"))

    conn = db()
    existing = conn.execute(
        f"SELECT id FROM {table} WHERE name=? LIMIT 1", (name,)
    ).fetchone()

    if existing:
        conn.execute(
            f"UPDATE {table} SET is_active=1, updated_at=CURRENT_TIMESTAMP WHERE id=?",
            (existing["id"],),
        )
    elif table == "finishing_options":
        sort_no = conn.execute(
            "SELECT COALESCE(MAX(sort_order),0)+1 AS n FROM finishing_options"
        ).fetchone()["n"]
        conn.execute(
            "INSERT INTO finishing_options(name,sort_order,is_active) VALUES(?,?,1)",
            (name, sort_no),
        )
    else:
        conn.execute(
            f"INSERT INTO {table}(name,is_active) VALUES(?,1)", (name,)
        )

    conn.commit()
    conn.close()
    return redirect(url_for("specs_list"))


@app.route("/specs/base/<kind>/<int:item_id>/toggle", methods=["POST"])
def specs_base_toggle(kind, item_id):
    table = SPEC_TABLES.get(kind)
    if not table:
        abort(404)

    conn = db()
    row = conn.execute(
        f"SELECT is_active FROM {table} WHERE id=?", (item_id,)
    ).fetchone()
    if not row:
        conn.close()
        abort(404)

    conn.execute(
        f"UPDATE {table} SET is_active=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
        (0 if row["is_active"] else 1, item_id),
    )
    conn.commit()
    conn.close()
    return redirect(url_for("specs_list"))


@app.route("/specs/product/<int:product_id>/relations", methods=["POST"])
def specs_product_relations(product_id):
    conn = db()
    relations = [
        ("product_materials", "material_id"),
        ("product_sizes", "size_id"),
        ("product_units", "unit_id"),
        ("product_finishings", "finishing_id"),
    ]

    for table, field in relations:
        conn.execute(f"DELETE FROM {table} WHERE product_id=?", (product_id,))
        for raw in request.form.getlist(field):
            try:
                related_id = int(raw)
            except (ValueError, TypeError):
                continue
            conn.execute(
                f"INSERT OR IGNORE INTO {table}(product_id,{field}) VALUES(?,?)",
                (product_id, related_id),
            )

    conn.commit()
    conn.close()
    flash("品項可用規格已更新。")
    return redirect(url_for("specs_list"))


@app.route("/specs/quick/new", methods=["POST"])
def specs_quick_new():
    name = request.form.get("name", "").strip()
    product_id = request.form.get("product_id", "").strip()

    if not name or not product_id:
        flash("常用規格名稱與品項為必填。")
        return redirect(url_for("specs_list"))

    conn = db()
    cur = conn.execute("""
        INSERT INTO quick_specs
        (name, product_id, material_id, size_id, unit_id,
         default_quantity, default_unit_price, note)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        name,
        int(product_id),
        request.form.get("material_id") or None,
        request.form.get("size_id") or None,
        request.form.get("unit_id") or None,
        request.form.get("default_quantity") or None,
        request.form.get("default_unit_price") or None,
        request.form.get("note", "").strip(),
    ))

    quick_id = int(cur.lastrowid)
    for raw in request.form.getlist("finishing_ids"):
        try:
            finishing_id = int(raw)
        except (ValueError, TypeError):
            continue
        conn.execute(
            "INSERT OR IGNORE INTO quick_spec_finishings(quick_spec_id,finishing_id) VALUES(?,?)",
            (quick_id, finishing_id),
        )

    conn.commit()
    conn.close()
    flash("常用規格已建立。")
    return redirect(url_for("specs_list"))


@app.route("/specs/quick/<int:quick_id>/toggle", methods=["POST"])
def specs_quick_toggle(quick_id):
    conn = db()
    row = conn.execute(
        "SELECT is_active FROM quick_specs WHERE id=?", (quick_id,)
    ).fetchone()
    if not row:
        conn.close()
        abort(404)

    conn.execute(
        "UPDATE quick_specs SET is_active=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
        (0 if row["is_active"] else 1, quick_id),
    )
    conn.commit()
    conn.close()
    return redirect(url_for("specs_list"))


@app.route("/api/specs/quick")
def api_specs_search():
    q = request.args.get("q", "").strip()
    conn = db()
    sql = """
        SELECT qs.id, qs.name AS quick_name,
               p.name AS product_name,
               m.name AS material, s.name AS size, u.name AS unit,
               qs.default_quantity AS quantity,
               qs.default_unit_price AS unit_price,
               COALESCE((
                    SELECT GROUP_CONCAT(fo.name, ',')
                    FROM quick_spec_finishings qsf
                    JOIN finishing_options fo ON fo.id=qsf.finishing_id
                    WHERE qsf.quick_spec_id=qs.id
               ), '') AS finishing
        FROM quick_specs qs
        JOIN products p ON p.id=qs.product_id
        LEFT JOIN materials m ON m.id=qs.material_id
        LEFT JOIN sizes s ON s.id=qs.size_id
        LEFT JOIN units u ON u.id=qs.unit_id
        WHERE qs.is_active=1
    """
    params = []
    if q:
        like = f"%{q}%"
        sql += """
          AND (
            qs.name LIKE ? OR p.name LIKE ? OR
            COALESCE(m.name,'') LIKE ? OR COALESCE(s.name,'') LIKE ?
          )
        """
        params.extend([like, like, like, like])
    sql += " ORDER BY qs.id DESC LIMIT 20"

    rows = conn.execute(sql, params).fetchall()
    conn.close()
    return jsonify(rows_dict(rows))


@app.route("/api/specs/products")
def api_spec_products():
    q = request.args.get("q", "").strip()
    conn = db()
    if q:
        rows = conn.execute(
            "SELECT id,name FROM products WHERE is_active=1 AND name LIKE ? ORDER BY name LIMIT 20",
            (f"%{q}%",),
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT id,name FROM products WHERE is_active=1 ORDER BY name LIMIT 50"
        ).fetchall()
    conn.close()
    return jsonify(rows_dict(rows))


@app.route("/api/specs/product-options")
def api_product_options():
    product_name = request.args.get("product", "").strip()
    empty = {
        "materials": [],
        "sizes": [],
        "units": [],
        "finishings": [],
        "quick_specs": [],
    }
    if not product_name:
        return jsonify(empty)

    conn = db()
    product = conn.execute(
        "SELECT id FROM products WHERE is_active=1 AND name=? LIMIT 1",
        (product_name,),
    ).fetchone()
    if not product:
        conn.close()
        return jsonify(empty)

    product_id = int(product["id"])

    materials = conn.execute("""
        SELECT m.id,m.name
        FROM materials m
        JOIN product_materials pm ON pm.material_id=m.id
        WHERE pm.product_id=? AND m.is_active=1
        ORDER BY m.name
    """, (product_id,)).fetchall()

    sizes = conn.execute("""
        SELECT s.id,s.name
        FROM sizes s
        JOIN product_sizes ps ON ps.size_id=s.id
        WHERE ps.product_id=? AND s.is_active=1
        ORDER BY s.name
    """, (product_id,)).fetchall()

    units = conn.execute("""
        SELECT u.id,u.name
        FROM units u
        JOIN product_units pu ON pu.unit_id=u.id
        WHERE pu.product_id=? AND u.is_active=1
        ORDER BY u.name
    """, (product_id,)).fetchall()

    finishings = conn.execute("""
        SELECT f.id,f.name
        FROM finishing_options f
        JOIN product_finishings pf ON pf.finishing_id=f.id
        WHERE pf.product_id=? AND f.is_active=1
        ORDER BY f.sort_order,f.name
    """, (product_id,)).fetchall()

    quick_specs = conn.execute("""
        SELECT qs.id,qs.name,
               m.name AS material,s.name AS size,u.name AS unit,
               qs.default_quantity AS quantity,
               qs.default_unit_price AS unit_price,
               COALESCE((
                    SELECT GROUP_CONCAT(fo.name, ',')
                    FROM quick_spec_finishings qsf
                    JOIN finishing_options fo ON fo.id=qsf.finishing_id
                    WHERE qsf.quick_spec_id=qs.id
               ), '') AS finishing
        FROM quick_specs qs
        LEFT JOIN materials m ON m.id=qs.material_id
        LEFT JOIN sizes s ON s.id=qs.size_id
        LEFT JOIN units u ON u.id=qs.unit_id
        WHERE qs.product_id=? AND qs.is_active=1
        ORDER BY qs.id DESC
    """, (product_id,)).fetchall()

    conn.close()
    return jsonify({
        "materials": rows_dict(materials),
        "sizes": rows_dict(sizes),
        "units": rows_dict(units),
        "finishings": rows_dict(finishings),
        "quick_specs": rows_dict(quick_specs),
    })


# ---------------- Projects ----------------

@app.route("/projects")
def projects_list():
    q = request.args.get("q", "").strip()
    conn = db()
    sql = """
        SELECT p.*, c.name AS customer_name,
               (SELECT COUNT(*) FROM quotes q WHERE q.project_id = p.id) AS quote_count,
               (SELECT COUNT(*) FROM orders o WHERE o.project_id = p.id) AS order_count
        FROM projects p
        JOIN customers c ON c.id = p.customer_id
        WHERE 1 = 1
    """
    params: list[Any] = []
    if q:
        sql += " AND (p.project_name LIKE ? OR c.name LIKE ?)"
        params.extend([f"%{q}%", f"%{q}%"])
    sql += " ORDER BY p.id DESC"
    rows = conn.execute(sql, params).fetchall()
    conn.close()
    return render_template("projects/list.html", projects=rows, q=q)


@app.route("/projects/new", methods=["GET", "POST"])
def projects_new():
    conn = db()
    customers = conn.execute("SELECT id, name, category FROM customers WHERE is_active = 1 ORDER BY name").fetchall()
    if request.method == "POST":
        customer_id = request.form.get("customer_id", "").strip()
        project_name = request.form.get("project_name", "").strip()
        if not customer_id or not project_name:
            flash("客戶與專案名稱皆為必填。")
            conn.close()
            return render_template("projects/detail.html", project=None, customers=customers, quotes=[], orders=[])
        cur = conn.execute(
            """
            INSERT INTO projects (customer_id, project_name, status, note)
            VALUES (?, ?, ?, ?)
            """,
            (
                int(customer_id),
                project_name,
                request.form.get("status", "進行中"),
                request.form.get("note", "").strip(),
            ),
        )
        conn.commit()
        pid = int(cur.lastrowid)
        conn.close()
        flash("專案已建立。")
        return redirect(url_for("projects_detail", project_id=pid))
    conn.close()
    return render_template("projects/detail.html", project=None, customers=customers, quotes=[], orders=[])


@app.route("/projects/<int:project_id>")
def projects_detail(project_id):
    conn = db()
    project = conn.execute(
        """
        SELECT p.*, c.name AS customer_name
        FROM projects p
        JOIN customers c ON c.id = p.customer_id
        WHERE p.id = ?
        """,
        (project_id,),
    ).fetchone()
    if not project:
        conn.close()
        abort(404)
    quotes = conn.execute(
        """
        SELECT q.*, q.quote_number AS number
        FROM quotes q
        WHERE q.project_id = ?
        ORDER BY q.id DESC
        """,
        (project_id,),
    ).fetchall()
    orders = conn.execute(
        """
        SELECT o.*, o.order_number AS number
        FROM orders o
        WHERE o.project_id = ?
        ORDER BY o.id DESC
        """,
        (project_id,),
    ).fetchall()
    conn.close()
    return render_template("projects/detail.html", project=project, quotes=quotes, orders=orders, customers=[])


# ---------------- Quotes ----------------

@app.route("/quotes")
def quotes_list():
    q = request.args.get("q", "").strip()
    status = request.args.get("status", "").strip()
    conn = db()
    refresh_expired_quotes(conn)
    conn.commit()
    sql = """
        SELECT q.*, c.name AS customer_name, p.project_name
        FROM quotes q
        JOIN customers c ON c.id = q.customer_id
        LEFT JOIN projects p ON p.id = q.project_id
        WHERE 1 = 1
    """
    params: list[Any] = []
    if q:
        sql += " AND (q.quote_number LIKE ? OR c.name LIKE ? OR COALESCE(p.project_name, '') LIKE ?)"
        params.extend([f"%{q}%", f"%{q}%", f"%{q}%"])
    if status:
        sql += " AND q.status = ?"
        params.append(status)
    sql += " ORDER BY q.id DESC"
    rows = conn.execute(sql, params).fetchall()
    conn.close()
    return render_template("quotes/list.html", quotes=rows, q=q, status=status)


@app.route("/quotes/new", methods=["GET", "POST"])
def quotes_new():
    conn = db()
    customers = conn.execute("SELECT id, name, category FROM customers WHERE is_active = 1 ORDER BY name").fetchall()
    projects = conn.execute(
        """
        SELECT p.id, p.customer_id, p.project_name, c.name AS customer_name
        FROM projects p
        JOIN customers c ON c.id = p.customer_id
        ORDER BY p.id DESC
        """
    ).fetchall()
    finishing_options = list_finishing_options(conn)

    if request.method == "POST":
        payload = parse_payload()
        if not payload:
            flash("表單資料有誤。")
            conn.close()
            return redirect(url_for("quotes_new"))
        try:
            quote_id = create_quote_from_payload(conn, payload)
            conn.commit()
        except Exception as e:
            conn.rollback()
            conn.close()
            flash(f"建立報價失敗：{e}")
            return redirect(url_for("quotes_new"))
        conn.close()
        flash("報價已建立。")
        return redirect(url_for("quotes_detail", quote_id=quote_id))

    conn.close()
    return render_template(
        "quotes/form.html",
        customers=customers,
        projects=projects,
        finishing_options=finishing_options,
        mode="normal",
        draft=None,
    )


@app.route("/quotes/<int:quote_id>")
def quotes_detail(quote_id):
    conn = db()
    quote = conn.execute(
        """
        SELECT q.*, c.name AS customer_name, c.contact_person, c.tax_id, c.phone, c.email, p.project_name
        FROM quotes q
        JOIN customers c ON c.id = q.customer_id
        LEFT JOIN projects p ON p.id = q.project_id
        WHERE q.id = ?
        """,
        (quote_id,),
    ).fetchone()
    if not quote:
        conn.close()
        abort(404)
    items = conn.execute(
        "SELECT * FROM quote_items WHERE quote_id = ? ORDER BY sort_order, id",
        (quote_id,),
    ).fetchall()
    work_units = conn.execute(
        "SELECT * FROM quote_work_units WHERE quote_id = ? ORDER BY sort_order, id",
        (quote_id,),
    ).fetchall()
    total = sum(float(r["subtotal"] or 0) for r in items)
    conn.close()
    return render_template("quotes/detail.html", quote=quote, items=items, work_units=work_units, total=total)


@app.route("/quotes/<int:quote_id>/status", methods=["POST"])
def quotes_status(quote_id):
    status = request.form.get("status", "").strip()
    if status not in QUOTE_STATUSES:
        flash("不支援的報價狀態。")
        return redirect(url_for("quotes_detail", quote_id=quote_id))
    conn = db()
    conn.execute(
        "UPDATE quotes SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
        (status, quote_id),
    )
    conn.commit()
    conn.close()
    flash("報價狀態已更新。")
    return redirect(url_for("quotes_detail", quote_id=quote_id))


@app.route("/quotes/<int:quote_id>/convert", methods=["POST"])
def quotes_convert(quote_id):
    conn = db()
    quote = conn.execute("SELECT * FROM quotes WHERE id = ?", (quote_id,)).fetchone()
    if not quote:
        conn.close()
        abort(404)
    try:
        order_id = convert_quote_to_order(conn, quote_id)
        conn.commit()
    except Exception as e:
        conn.rollback()
        conn.close()
        flash(f"轉訂單失敗：{e}")
        return redirect(url_for("quotes_detail", quote_id=quote_id))
    conn.close()
    flash("已轉成訂單。")
    return redirect(url_for("orders_detail", order_id=order_id))


# ---------------- Orders ----------------

@app.route("/orders")
def orders_list():
    q = request.args.get("q", "").strip()
    status = request.args.get("status", "").strip()
    conn = db()
    sql = """
        SELECT o.*, c.name AS customer_name, p.project_name, q.quote_number
        FROM orders o
        JOIN customers c ON c.id = o.customer_id
        LEFT JOIN projects p ON p.id = o.project_id
        LEFT JOIN quotes q ON q.id = o.quote_id
        WHERE 1 = 1
    """
    params: list[Any] = []
    if q:
        sql += " AND (o.order_number LIKE ? OR c.name LIKE ? OR COALESCE(p.project_name, '') LIKE ?)"
        params.extend([f"%{q}%", f"%{q}%", f"%{q}%"])
    if status:
        sql += " AND o.status = ?"
        params.append(status)
    sql += " ORDER BY o.id DESC"
    rows = conn.execute(sql, params).fetchall()
    conn.close()
    return render_template("orders/list.html", orders=rows, q=q, status=status)


@app.route("/orders/new", methods=["GET", "POST"])
def orders_new():
    conn = db()
    customers = conn.execute("SELECT id, name, category FROM customers WHERE is_active = 1 ORDER BY name").fetchall()
    projects = conn.execute(
        """
        SELECT p.id, p.customer_id, p.project_name, c.name AS customer_name
        FROM projects p
        JOIN customers c ON c.id = p.customer_id
        ORDER BY p.id DESC
        """
    ).fetchall()
    finishing_options = list_finishing_options(conn)

    if request.method == "POST":
        payload = parse_payload()
        if not payload:
            flash("表單資料有誤。")
            conn.close()
            return redirect(url_for("orders_new"))
        try:
            order_id = create_order_from_payload(conn, payload, source_quote_id=None)
            conn.commit()
        except Exception as e:
            conn.rollback()
            conn.close()
            flash(f"建立訂單失敗：{e}")
            return redirect(url_for("orders_new"))
        conn.close()
        flash("訂單已建立。")
        return redirect(url_for("orders_detail", order_id=order_id))

    conn.close()
    return render_template(
        "orders/form.html",
        customers=customers,
        projects=projects,
        finishing_options=finishing_options,
        smart_search_endpoint=url_for("api_orders_smart_search"),
        draft=None,
    )


@app.route("/orders/<int:order_id>")
def orders_detail(order_id):
    conn = db()
    order = conn.execute(
        """
        SELECT o.*, c.name AS customer_name, c.contact_person, c.tax_id, c.phone, c.email, p.project_name, q.quote_number
        FROM orders o
        JOIN customers c ON c.id = o.customer_id
        LEFT JOIN projects p ON p.id = o.project_id
        LEFT JOIN quotes q ON q.id = o.quote_id
        WHERE o.id = ?
        """,
        (order_id,),
    ).fetchone()
    if not order:
        conn.close()
        abort(404)
    items = conn.execute(
        "SELECT * FROM order_items WHERE order_id = ? ORDER BY sort_order, id",
        (order_id,),
    ).fetchall()
    work_units = conn.execute(
        "SELECT * FROM order_work_units WHERE order_id = ? ORDER BY sort_order, id",
        (order_id,),
    ).fetchall()
    total = sum(float(r["subtotal"] or 0) for r in items)
    conn.close()
    return render_template("orders/detail.html", order=order, items=items, work_units=work_units, total=total)


@app.route("/orders/<int:order_id>/status", methods=["POST"])
def orders_status(order_id):
    status = request.form.get("status", "").strip()
    if status not in ORDER_STATUSES:
        flash("不支援的訂單狀態。")
        return redirect(url_for("orders_detail", order_id=order_id))
    conn = db()
    conn.execute(
        "UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
        (status, order_id),
    )
    conn.commit()
    conn.close()
    flash("訂單狀態已更新。")
    return redirect(url_for("orders_detail", order_id=order_id))


@app.route("/api/orders/smart-search")
def api_orders_smart_search():
    q = request.args.get("q", "").strip()
    conn = db()
    rows = search_order_items(conn, q, limit=20) if q else []
    conn.close()
    return jsonify(rows)


# ---------------- Export / backup basics ----------------

@app.route("/admin/export/json")
def admin_export_json():
    conn = db()
    data = {}
    for table in [
        "customers", "projects", "spec_presets", "finishing_options",
        "quotes", "quote_work_units", "quote_items",
        "orders", "order_work_units", "order_items",
        "daily_sequences",
    ]:
        rows = conn.execute(f"SELECT * FROM {table}").fetchall()
        data[table] = rows_dict(rows)
    conn.close()
    return jsonify(data)


@app.route("/healthz")
def healthz():
    return {"ok": True}


if __name__ == "__main__":
    init_database()
    app.run(host="0.0.0.0", port=5000, debug=True)
