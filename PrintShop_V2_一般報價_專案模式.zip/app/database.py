import sqlite3
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATABASE_DIR = BASE_DIR / "database"
DATABASE_DIR.mkdir(exist_ok=True)
DATABASE_PATH = DATABASE_DIR / "printshop.db"


def get_connection():
    connection = sqlite3.connect(DATABASE_PATH)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


def init_database():
    connection = get_connection()

    connection.executescript("""
    CREATE TABLE IF NOT EXISTS customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_name TEXT NOT NULL,
        contact_person TEXT DEFAULT '',
        tax_id TEXT DEFAULT '',
        phone TEXT DEFAULT '',
        category TEXT DEFAULT '一般',
        is_active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS projects (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER NOT NULL,
        project_name TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT '進行中',
        note TEXT DEFAULT '',
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (customer_id) REFERENCES customers(id)
    );

    CREATE TABLE IF NOT EXISTS quotes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        quote_number TEXT NOT NULL UNIQUE,
        customer_id INTEGER NOT NULL,
        project_id INTEGER DEFAULT NULL,
        mode TEXT NOT NULL DEFAULT 'normal',
        status TEXT NOT NULL DEFAULT '報價中',
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (customer_id) REFERENCES customers(id),
        FOREIGN KEY (project_id) REFERENCES projects(id)
    );

    CREATE TABLE IF NOT EXISTS quote_work_units (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        quote_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        note TEXT DEFAULT '',
        sort_order INTEGER NOT NULL DEFAULT 0,
        FOREIGN KEY (quote_id) REFERENCES quotes(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS quote_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        quote_id INTEGER NOT NULL,
        work_unit_id INTEGER DEFAULT NULL,
        product_name TEXT NOT NULL,
        material TEXT DEFAULT '',
        size TEXT DEFAULT '',
        finishing TEXT DEFAULT '',
        quantity REAL NOT NULL DEFAULT 0,
        unit TEXT DEFAULT '',
        unit_price REAL NOT NULL DEFAULT 0,
        subtotal REAL NOT NULL DEFAULT 0,
        sort_order INTEGER NOT NULL DEFAULT 0,
        FOREIGN KEY (quote_id) REFERENCES quotes(id) ON DELETE CASCADE,
        FOREIGN KEY (work_unit_id) REFERENCES quote_work_units(id) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_projects_customer ON projects(customer_id);
    CREATE INDEX IF NOT EXISTS idx_quotes_customer ON quotes(customer_id);
    CREATE INDEX IF NOT EXISTS idx_quotes_project ON quotes(project_id);
    CREATE INDEX IF NOT EXISTS idx_quote_units_quote ON quote_work_units(quote_id);
    CREATE INDEX IF NOT EXISTS idx_quote_items_quote ON quote_items(quote_id);
    CREATE INDEX IF NOT EXISTS idx_quote_items_unit ON quote_items(work_unit_id);
    """)

    # 對早期 V1 資料做最低限度結構補齊，不刪除既有資料。
    quote_columns = {
        row["name"] for row in connection.execute("PRAGMA table_info(quotes)")
    }
    if "project_id" not in quote_columns:
        connection.execute("ALTER TABLE quotes ADD COLUMN project_id INTEGER")
    if "mode" not in quote_columns:
        connection.execute(
            "ALTER TABLE quotes ADD COLUMN mode TEXT NOT NULL DEFAULT 'normal'"
        )

    item_columns = {
        row["name"] for row in connection.execute("PRAGMA table_info(quote_items)")
    }
    if "work_unit_id" not in item_columns:
        connection.execute("ALTER TABLE quote_items ADD COLUMN work_unit_id INTEGER")
    if "sort_order" not in item_columns:
        connection.execute(
            "ALTER TABLE quote_items ADD COLUMN sort_order INTEGER NOT NULL DEFAULT 0"
        )

    connection.commit()
    connection.close()
