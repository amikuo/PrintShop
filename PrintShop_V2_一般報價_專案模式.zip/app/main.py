from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for

from database import init_database, get_connection

app = Flask(__name__)
init_database()


@app.route("/")
def index():
    return render_template("index.html")


# ---------- Customers ----------

@app.route("/customers")
def customers():
    connection = get_connection()
    rows = connection.execute("""
        SELECT id, company_name, contact_person, tax_id, phone, category
        FROM customers
        WHERE is_active = 1
        ORDER BY company_name COLLATE NOCASE
    """).fetchall()
    connection.close()
    return render_template("customers/list.html", customers=rows)


@app.route("/customers/new", methods=["GET", "POST"])
def new_customer():
    if request.method == "POST":
        company_name = request.form.get("company_name", "").strip()
        contact_person = request.form.get("contact_person", "").strip()
        tax_id = request.form.get("tax_id", "").strip()
        phone = request.form.get("phone", "").strip()
        category = request.form.get("category", "一般").strip() or "一般"

        if not company_name:
            return "客戶名稱為必填欄位", 400

        connection = get_connection()
        connection.execute("""
            INSERT INTO customers
            (company_name, contact_person, tax_id, phone, category)
            VALUES (?, ?, ?, ?, ?)
        """, (company_name, contact_person, tax_id, phone, category))
        connection.commit()
        connection.close()
        return redirect(url_for("customers"))

    return render_template("customers/form.html")


@app.route("/customers/<int:customer_id>/edit", methods=["GET", "POST"])
def edit_customer(customer_id):
    connection = get_connection()

    if request.method == "POST":
        company_name = request.form.get("company_name", "").strip()
        contact_person = request.form.get("contact_person", "").strip()
        tax_id = request.form.get("tax_id", "").strip()
        phone = request.form.get("phone", "").strip()
        category = request.form.get("category", "一般").strip() or "一般"

        if not company_name:
            connection.close()
            return "客戶名稱為必填欄位", 400

        connection.execute("""
            UPDATE customers
            SET company_name = ?,
                contact_person = ?,
                tax_id = ?,
                phone = ?,
                category = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        """, (
            company_name, contact_person, tax_id, phone, category, customer_id
        ))
        connection.commit()
        connection.close()
        return redirect(url_for("customers"))

    customer = connection.execute("""
        SELECT id, company_name, contact_person, tax_id, phone, category
        FROM customers
        WHERE id = ? AND is_active = 1
    """, (customer_id,)).fetchone()
    connection.close()

    if customer is None:
        return "找不到此客戶", 404

    return render_template("customers/form.html", customer=customer)


# ---------- Quotes / Projects ----------

def generate_quote_number(connection):
    prefix = datetime.now().strftime("%y%m%d")
    row = connection.execute("""
        SELECT quote_number
        FROM quotes
        WHERE quote_number LIKE ?
        ORDER BY quote_number DESC
        LIMIT 1
    """, (prefix + "%",)).fetchone()

    if row is None:
        seq = 1
    else:
        try:
            seq = int(str(row["quote_number"])[-2:]) + 1
        except (ValueError, TypeError):
            seq = 1

    return prefix + f"{seq:02d}"


def active_customers(connection):
    return connection.execute("""
        SELECT id, company_name, contact_person, tax_id, phone, category
        FROM customers
        WHERE is_active = 1
        ORDER BY company_name COLLATE NOCASE
    """).fetchall()


def parse_items(form):
    names = form.getlist("product_name[]")
    materials = form.getlist("material[]")
    sizes = form.getlist("size[]")
    finishings = form.getlist("finishing[]")
    quantities = form.getlist("quantity[]")
    units = form.getlist("unit[]")
    prices = form.getlist("unit_price[]")
    work_indexes = form.getlist("work_unit_index[]")

    result = []

    def get(values, i):
        return values[i].strip() if i < len(values) else ""

    for i, name in enumerate(names):
        name = name.strip()
        if not name:
            continue
        try:
            quantity = float(get(quantities, i) or 0)
            unit_price = float(get(prices, i) or 0)
        except ValueError:
            raise ValueError("數量或單價格式錯誤")

        result.append({
            "product_name": name,
            "material": get(materials, i),
            "size": get(sizes, i),
            "finishing": get(finishings, i),
            "quantity": quantity,
            "unit": get(units, i),
            "unit_price": unit_price,
            "subtotal": quantity * unit_price,
            "work_unit_index": get(work_indexes, i)
        })

    return result


@app.route("/quotes")
def quotes():
    connection = get_connection()
    rows = connection.execute("""
        SELECT q.id, q.quote_number, q.status, q.mode, q.created_at,
               c.company_name, p.project_name,
               COALESCE(SUM(qi.subtotal), 0) AS total
        FROM quotes q
        JOIN customers c ON c.id = q.customer_id
        LEFT JOIN projects p ON p.id = q.project_id
        LEFT JOIN quote_items qi ON qi.quote_id = q.id
        GROUP BY q.id
        ORDER BY q.id DESC
    """).fetchall()
    connection.close()
    return render_template("quotes/list.html", quotes=rows)


@app.route("/quotes/new", methods=["GET", "POST"])
def new_quote():
    connection = get_connection()

    if request.method == "POST":
        customer_raw = request.form.get("customer_id", "").strip()
        mode = request.form.get("mode", "normal")
        project_raw = request.form.get("project_id", "").strip()
        new_project_name = request.form.get("new_project_name", "").strip()

        if not customer_raw:
            connection.close()
            return "請先選擇客戶", 400
        try:
            customer_id = int(customer_raw)
        except ValueError:
            connection.close()
            return "客戶資料無效", 400

        project_id = None

        if mode == "project":
            if project_raw == "new":
                if not new_project_name:
                    connection.close()
                    return "請輸入專案名稱", 400
                cur = connection.execute("""
                    INSERT INTO projects (customer_id, project_name)
                    VALUES (?, ?)
                """, (customer_id, new_project_name))
                project_id = cur.lastrowid
            elif project_raw:
                try:
                    project_id = int(project_raw)
                except ValueError:
                    connection.close()
                    return "專案資料無效", 400

                valid = connection.execute("""
                    SELECT id FROM projects
                    WHERE id = ? AND customer_id = ?
                """, (project_id, customer_id)).fetchone()
                if valid is None:
                    connection.close()
                    return "專案與客戶不符", 400
            else:
                connection.close()
                return "專案模式需要選擇或建立專案", 400

        try:
            items = parse_items(request.form)
        except ValueError as exc:
            connection.close()
            return str(exc), 400

        if not items:
            connection.close()
            return "至少需要一筆報價品項", 400

        work_names = []
        if mode == "project":
            work_names = [
                name.strip()
                for name in request.form.getlist("work_unit_name[]")
                if name.strip()
            ]
            if not work_names:
                connection.close()
                return "專案模式至少需要一個工作單位", 400

            for item in items:
                try:
                    idx = int(item["work_unit_index"])
                except (ValueError, TypeError):
                    connection.close()
                    return "專案品項缺少工作單位", 400
                if idx < 0 or idx >= len(work_names):
                    connection.close()
                    return "工作單位資料無效", 400
                item["work_unit_index"] = idx
        else:
            for item in items:
                item["work_unit_index"] = None

        quote_number = generate_quote_number(connection)
        cur = connection.execute("""
            INSERT INTO quotes
            (quote_number, customer_id, project_id, mode, status)
            VALUES (?, ?, ?, ?, '報價中')
        """, (
            quote_number,
            customer_id,
            project_id,
            "project" if mode == "project" else "normal"
        ))
        quote_id = cur.lastrowid

        unit_ids = []
        for sort_order, name in enumerate(work_names):
            cur = connection.execute("""
                INSERT INTO quote_work_units (quote_id, name, sort_order)
                VALUES (?, ?, ?)
            """, (quote_id, name, sort_order))
            unit_ids.append(cur.lastrowid)

        for sort_order, item in enumerate(items):
            work_unit_id = (
                unit_ids[item["work_unit_index"]]
                if item["work_unit_index"] is not None else None
            )
            connection.execute("""
                INSERT INTO quote_items
                (quote_id, work_unit_id, product_name, material, size, finishing,
                 quantity, unit, unit_price, subtotal, sort_order)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                quote_id, work_unit_id, item["product_name"], item["material"],
                item["size"], item["finishing"], item["quantity"], item["unit"],
                item["unit_price"], item["subtotal"], sort_order
            ))

        connection.commit()
        connection.close()
        return redirect(url_for("quote_detail", quote_id=quote_id))

    customers_rows = active_customers(connection)
    projects_rows = connection.execute("""
        SELECT id, customer_id, project_name, status
        FROM projects
        ORDER BY created_at DESC
    """).fetchall()
    connection.close()

    return render_template(
        "quotes/form.html",
        customers=customers_rows,
        projects=projects_rows
    )


@app.route("/quotes/<int:quote_id>")
def quote_detail(quote_id):
    connection = get_connection()

    quote = connection.execute("""
        SELECT q.id, q.quote_number, q.status, q.mode, q.created_at,
               c.company_name, c.contact_person, c.tax_id, c.phone,
               p.id AS project_id, p.project_name
        FROM quotes q
        JOIN customers c ON c.id = q.customer_id
        LEFT JOIN projects p ON p.id = q.project_id
        WHERE q.id = ?
    """, (quote_id,)).fetchone()

    if quote is None:
        connection.close()
        return "找不到此報價", 404

    units = connection.execute("""
        SELECT id, name, note, sort_order
        FROM quote_work_units
        WHERE quote_id = ?
        ORDER BY sort_order, id
    """, (quote_id,)).fetchall()

    items = connection.execute("""
        SELECT *
        FROM quote_items
        WHERE quote_id = ?
        ORDER BY sort_order, id
    """, (quote_id,)).fetchall()

    connection.close()

    total = sum(float(i["subtotal"] or 0) for i in items)
    grouped = [
        {
            "unit": unit,
            "items": [i for i in items if i["work_unit_id"] == unit["id"]]
        }
        for unit in units
    ]

    return render_template(
        "quotes/detail.html",
        quote=quote,
        items=items,
        grouped=grouped,
        total=total
    )


@app.route("/projects")
def project_list():
    connection = get_connection()
    rows = connection.execute("""
        SELECT p.id, p.project_name, p.status, p.created_at,
               c.company_name,
               COUNT(DISTINCT q.id) AS quote_count,
               COALESCE(SUM(qi.subtotal), 0) AS total
        FROM projects p
        JOIN customers c ON c.id = p.customer_id
        LEFT JOIN quotes q ON q.project_id = p.id
        LEFT JOIN quote_items qi ON qi.quote_id = q.id
        GROUP BY p.id
        ORDER BY p.id DESC
    """).fetchall()
    connection.close()
    return render_template("projects/list.html", projects=rows)


@app.route("/projects/<int:project_id>")
def project_detail(project_id):
    connection = get_connection()

    project = connection.execute("""
        SELECT p.id, p.project_name, p.status, p.note, c.company_name
        FROM projects p
        JOIN customers c ON c.id = p.customer_id
        WHERE p.id = ?
    """, (project_id,)).fetchone()

    if project is None:
        connection.close()
        return "找不到此專案", 404

    quotes_rows = connection.execute("""
        SELECT q.id, q.quote_number, q.status, q.mode, q.created_at,
               COALESCE(SUM(qi.subtotal), 0) AS total
        FROM quotes q
        LEFT JOIN quote_items qi ON qi.quote_id = q.id
        WHERE q.project_id = ?
        GROUP BY q.id
        ORDER BY q.id DESC
    """, (project_id,)).fetchall()

    connection.close()
    return render_template(
        "projects/detail.html",
        project=project,
        quotes=quotes_rows
    )


@app.route("/db-test")
def db_test():
    connection = get_connection()
    tables = connection.execute("""
        SELECT name FROM sqlite_master
        WHERE type='table'
        ORDER BY name
    """).fetchall()
    connection.close()
    return {"status": "ok", "tables": [r["name"] for r in tables]}


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
