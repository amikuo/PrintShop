from flask import Flask, render_template, request, redirect, url_for
from database import init_database, get_connection
from datetime import datetime

app = Flask(__name__)

# 啟動 Flask 時確保 SQLite 資料庫已初始化
init_database()


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/customers")
def customers():
    connection = get_connection()
    rows = connection.execute("""
        SELECT id, company_name, contact_person, tax_id, phone, category
        FROM customers
        WHERE is_active = 1
        ORDER BY company_name COLLATE NOCASE
    """).fetchall()
    connection.close()

    return render_template("customers/list.html", customers=rows)


@app.route("/customers/new", methods=["GET", "POST"])
def new_customer():
    if request.method == "POST":
        company_name = request.form.get("company_name", "").strip()
        contact_person = request.form.get("contact_person", "").strip()
        tax_id = request.form.get("tax_id", "").strip()
        phone = request.form.get("phone", "").strip()
        category = request.form.get("category", "一般").strip()

        if not company_name:
            return "客戶名稱為必填欄位", 400

        connection = get_connection()
        connection.execute(
            """
            INSERT INTO customers
            (company_name, contact_person, tax_id, phone, category)
            VALUES (?, ?, ?, ?, ?)
            """,
            (company_name, contact_person, tax_id, phone, category)
        )
        connection.commit()
        connection.close()

        return redirect(url_for("customers"))

    return render_template("customers/form.html")


@app.route("/customers/<int:customer_id>/edit", methods=["GET", "POST"])
def edit_customer(customer_id):
    connection = get_connection()

    if request.method == "POST":
        company_name = request.form.get("company_name", "").strip()
        contact_person = request.form.get("contact_person", "").strip()
        tax_id = request.form.get("tax_id", "").strip()
        phone = request.form.get("phone", "").strip()
        category = request.form.get("category", "一般").strip()

        if not company_name:
            connection.close()
            return "客戶名稱為必填欄位", 400

        connection.execute("""
            UPDATE customers
            SET company_name = ?,
                contact_person = ?,
                tax_id = ?,
                phone = ?,
                category = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        """, (
            company_name, contact_person, tax_id, phone, category, customer_id
        ))
        connection.commit()
        connection.close()

        return redirect("/customers")

    customer = connection.execute("""
        SELECT id, company_name, contact_person, tax_id, phone, category
        FROM customers
        WHERE id = ? AND is_active = 1
    """, (customer_id,)).fetchone()

    connection.close()

    if customer is None:
        return "找不到此客戶", 404

    return render_template("customers/form.html", customer=customer)


def generate_quote_number(connection):
    """格式：YYYYMMDD + 當日序號，例如 26080801。"""
    prefix = datetime.now().strftime("%y%m%d")
    row = connection.execute("""
        SELECT quote_number
        FROM quotes
        WHERE quote_number LIKE ?
        ORDER BY quote_number DESC
        LIMIT 1
    """, (prefix + "%",)).fetchone()

    if row is None:
        return prefix + "01"

    last = row["quote_number"]
    try:
        sequence = int(last[-2:]) + 1
    except (ValueError, TypeError):
        sequence = 1

    return prefix + f"{sequence:02d}"


@app.route("/quotes")
def quotes():
    connection = get_connection()
    rows = connection.execute("""
        SELECT
            q.id,
            q.quote_number,
            q.status,
            q.created_at,
            c.company_name,
            COALESCE(SUM(qi.subtotal), 0) AS total
        FROM quotes q
        JOIN customers c ON c.id = q.customer_id
        LEFT JOIN quote_items qi ON qi.quote_id = q.id
        GROUP BY q.id
        ORDER BY q.id DESC
    """).fetchall()
    connection.close()

    return render_template("quotes/list.html", quotes=rows)


@app.route("/quotes/new", methods=["GET", "POST"])
def new_quote():
    connection = get_connection()

    if request.method == "POST":
        customer_id = request.form.get("customer_id", "").strip()
        new_customer_name = request.form.get("new_customer_name", "").strip()

        # 新客戶：只在使用者確定儲存報價時建立
        if not customer_id and new_customer_name:
            customer = connection.execute("""
                SELECT id FROM customers
                WHERE company_name = ? AND is_active = 1
                LIMIT 1
            """, (new_customer_name,)).fetchone()

            if customer:
                customer_id = str(customer["id"])
            else:
                connection.execute("""
                    INSERT INTO customers
                    (company_name, contact_person, tax_id, phone, category)
                    VALUES (?, ?, ?, ?, ?)
                """, (
                    new_customer_name,
                    request.form.get("new_contact_person", "").strip(),
                    request.form.get("new_tax_id", "").strip(),
                    request.form.get("new_phone", "").strip(),
                    request.form.get("new_category", "一般").strip() or "一般"
                ))
                customer_id = str(connection.execute(
                    "SELECT last_insert_rowid()"
                ).fetchone()[0])

        if not customer_id:
            connection.close()
            return "請先選擇或建立客戶", 400

        try:
            customer_id_int = int(customer_id)
        except ValueError:
            connection.close()
            return "客戶資料無效", 400

        # 一次報價可包含多筆品項
        product_names = request.form.getlist("product_name[]")
        materials = request.form.getlist("material[]")
        sizes = request.form.getlist("size[]")
        finishings = request.form.getlist("finishing[]")
        quantities = request.form.getlist("quantity[]")
        units = request.form.getlist("unit[]")
        unit_prices = request.form.getlist("unit_price[]")

        items = []
        for i, product_name in enumerate(product_names):
            product_name = product_name.strip()
            if not product_name:
                continue

            def get_at(values, index, default=""):
                return values[index] if index < len(values) else default

            try:
                quantity = float(get_at(quantities, i, "0") or 0)
                unit_price = float(get_at(unit_prices, i, "0") or 0)
            except ValueError:
                connection.close()
                return "數量或單價格式錯誤", 400

            subtotal = quantity * unit_price

            items.append((
                product_name,
                get_at(materials, i).strip(),
                get_at(sizes, i).strip(),
                get_at(finishings, i).strip(),
                quantity,
                get_at(units, i).strip(),
                unit_price,
                subtotal
            ))

        if not items:
            connection.close()
            return "至少需要一筆報價品項", 400

        quote_number = generate_quote_number(connection)

        cursor = connection.execute("""
            INSERT INTO quotes (quote_number, customer_id, status)
            VALUES (?, ?, '報價中')
        """, (quote_number, customer_id_int))
        quote_id = cursor.lastrowid

        connection.executemany("""
            INSERT INTO quote_items
            (quote_id, product_name, material, size, finishing,
             quantity, unit, unit_price, subtotal)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, [
            (quote_id, *item) for item in items
        ])

        connection.commit()
        connection.close()

        return redirect(url_for("quote_detail", quote_id=quote_id))

    customers_rows = connection.execute("""
        SELECT id, company_name, contact_person, tax_id, phone, category
        FROM customers
        WHERE is_active = 1
        ORDER BY company_name COLLATE NOCASE
    """).fetchall()
    connection.close()

    return render_template("quotes/form.html", customers=customers_rows)


@app.route("/quotes/<int:quote_id>")
def quote_detail(quote_id):
    connection = get_connection()

    quote = connection.execute("""
        SELECT
            q.id, q.quote_number, q.status, q.created_at,
            c.company_name, c.contact_person, c.tax_id, c.phone, c.category
        FROM quotes q
        JOIN customers c ON c.id = q.customer_id
        WHERE q.id = ?
    """, (quote_id,)).fetchone()

    items = connection.execute("""
        SELECT product_name, material, size, finishing,
               quantity, unit, unit_price, subtotal
        FROM quote_items
        WHERE quote_id = ?
        ORDER BY id
    """, (quote_id,)).fetchall()

    connection.close()

    if quote is None:
        return "找不到此報價", 404

    total = sum(float(item["subtotal"] or 0) for item in items)

    return render_template(
        "quotes/detail.html",
        quote=quote,
        items=items,
        total=total
    )


@app.route("/db-test")
def db_test():
    return {
        "status": "ok",
        "database": "SQLite",
        "message": "資料庫連線正常"
    }


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
