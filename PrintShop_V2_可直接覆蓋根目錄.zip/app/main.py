from datetime import datetime
from flask import Flask,abort,flash,jsonify,redirect,render_template,request,url_for
try: from .database import get_connection,init_database
except ImportError: from database import get_connection,init_database
app=Flask(__name__); app.secret_key="printshop-v2-local"
CATEGORIES=["一般","學校","政府","公司","宮廟/社團"]; QUOTE_STATUSES=["報價中","已確認","製作中","已完成","已取消"]; PROJECT_STATUSES=["進行中","暫停","已完成","已取消"]
@app.context_processor
def opts(): return {"categories":CATEGORIES,"quote_statuses":QUOTE_STATUSES,"project_statuses":PROJECT_STATUSES}
@app.template_filter("money")
def money(v):
    try:return f"{float(v):,.0f}"
    except:return "0"
def qno(i): return f"Q{datetime.now():%Y%m%d}-{i:04d}"
def save_items(c,qid):
    ks=["product_name","material","size","finishing","quantity","unit","unit_price"]; vs={k:request.form.getlist(k+"[]") for k in ks}
    for i,name in enumerate(vs["product_name"]):
        name=name.strip()
        if not name: continue
        def v(k,d=""): return vs[k][i].strip() if i<len(vs[k]) else d
        try: qty=float(v("quantity","0") or 0)
        except: qty=0
        try: price=float(v("unit_price","0") or 0)
        except: price=0
        c.execute("INSERT INTO quote_items(quote_id,product_name,material,size,finishing,quantity,unit,unit_price,subtotal,sort_order) VALUES(?,?,?,?,?,?,?,?,?,?)",(qid,name,v("material"),v("size"),v("finishing"),qty,v("unit"),price,qty*price,i))
@app.route("/")
def index():
    c=get_connection(); stats={"customers":c.execute("SELECT COUNT(*) FROM customers WHERE is_active=1").fetchone()[0],"quotes":c.execute("SELECT COUNT(*) FROM quotes").fetchone()[0],"active_quotes":c.execute("SELECT COUNT(*) FROM quotes WHERE status IN ('報價中','已確認')").fetchone()[0],"projects":c.execute("SELECT COUNT(*) FROM projects WHERE status='進行中'").fetchone()[0]}
    rows=c.execute("SELECT q.*,c.name customer_name,p.project_name FROM quotes q JOIN customers c ON c.id=q.customer_id LEFT JOIN projects p ON p.id=q.project_id ORDER BY q.id DESC LIMIT 8").fetchall(); c.close(); return render_template("index.html",stats=stats,recent_quotes=rows)
@app.route("/customers")
def customers():
    q=request.args.get("q","").strip(); c=get_connection()
    rows=c.execute("SELECT * FROM customers WHERE is_active=1 AND (name LIKE ? OR phone LIKE ? OR email LIKE ?) ORDER BY name",(f"%{q}%",f"%{q}%",f"%{q}%")).fetchall() if q else c.execute("SELECT * FROM customers WHERE is_active=1 ORDER BY id DESC").fetchall()
    c.close(); return render_template("customers/list.html",customers=rows,q=q)
@app.route("/customers/new",methods=["GET","POST"])
def customer_new():
    if request.method=="POST":
        name=request.form.get("name","").strip()
        if not name: flash("客戶名稱不能空白。","error"); return render_template("customers/form.html",customer=None)
        c=get_connection(); cur=c.execute("INSERT INTO customers(name,phone,email,address,category,note) VALUES(?,?,?,?,?,?)",(name,request.form.get("phone","").strip(),request.form.get("email","").strip(),request.form.get("address","").strip(),request.form.get("category","一般"),request.form.get("note","").strip())); c.commit(); cid=cur.lastrowid; c.close(); return redirect(url_for("customer_edit",customer_id=cid))
    return render_template("customers/form.html",customer=None)
@app.route("/customers/<int:customer_id>/edit",methods=["GET","POST"])
def customer_edit(customer_id):
    c=get_connection(); row=c.execute("SELECT * FROM customers WHERE id=?",(customer_id,)).fetchone()
    if not row:c.close();abort(404)
    if request.method=="POST":
        c.execute("UPDATE customers SET name=?,phone=?,email=?,address=?,category=?,note=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",(request.form.get("name","").strip(),request.form.get("phone","").strip(),request.form.get("email","").strip(),request.form.get("address","").strip(),request.form.get("category","一般"),request.form.get("note","").strip(),customer_id)); c.commit(); c.close(); return redirect(url_for("customers"))
    c.close(); return render_template("customers/form.html",customer=row)
@app.route("/api/customers/search")
def customer_search():
    q=request.args.get("q","").strip()
    if not q:return jsonify([])
    c=get_connection(); rows=c.execute("SELECT id,name,phone,category FROM customers WHERE is_active=1 AND name LIKE ? ORDER BY CASE WHEN name LIKE ? THEN 0 ELSE 1 END,name LIMIT 12",(f"%{q}%",f"{q}%")).fetchall(); c.close(); return jsonify([dict(r) for r in rows])
@app.route("/quotes")
def quotes():
    q=request.args.get("q","").strip(); status=request.args.get("status","").strip(); c=get_connection(); sql="SELECT q.*,c.name customer_name,p.project_name FROM quotes q JOIN customers c ON c.id=q.customer_id LEFT JOIN projects p ON p.id=q.project_id WHERE 1=1"; ps=[]
    if q:sql+=" AND (q.quote_number LIKE ? OR c.name LIKE ? OR COALESCE(p.project_name,'') LIKE ?)"; ps += [f"%{q}%"]*3
    if status:sql+=" AND q.status=?"; ps.append(status)
    rows=c.execute(sql+" ORDER BY q.id DESC",ps).fetchall(); c.close(); return render_template("quotes/list.html",quotes=rows,q=q,status=status)
def qdata(c): return c.execute("SELECT id,name,phone,category FROM customers WHERE is_active=1 ORDER BY name").fetchall(),c.execute("SELECT p.id,p.customer_id,p.project_name,p.status,c.name customer_name FROM projects p JOIN customers c ON c.id=p.customer_id ORDER BY p.id DESC").fetchall()
@app.route("/quotes/new",methods=["GET","POST"])
def quote_new():
    c=get_connection(); cs,ps=qdata(c)
    if request.method=="POST":
        cid=request.form.get("customer_id","").strip(); cname=request.form.get("customer_name","").strip()
        if not cid and cname:
            e=c.execute("SELECT id FROM customers WHERE is_active=1 AND name=?",(cname,)).fetchone()
            if e:cid=str(e["id"])
            else: cid=str(c.execute("INSERT INTO customers(name) VALUES(?)",(cname,)).lastrowid)
        if not cid:c.close();flash("請輸入或選擇客戶。","error");return render_template("quotes/form.html",customers=cs,projects=ps)
        pid=request.form.get("project_id") or None
        if pid:
            p=c.execute("SELECT customer_id FROM projects WHERE id=?",(pid,)).fetchone()
            if not p or int(p["customer_id"])!=int(cid):pid=None
        cur=c.execute("INSERT INTO quotes(quote_number,customer_id,project_id,mode,status,note) VALUES(?,?,?,?,?,?)",("TEMP",int(cid),pid,request.form.get("mode","normal"),request.form.get("status","報價中"),request.form.get("note","").strip())); qid=cur.lastrowid
        c.execute("UPDATE quotes SET quote_number=? WHERE id=?",(qno(qid),qid)); save_items(c,qid); c.commit(); c.close(); return redirect(url_for("quote_detail",quote_id=qid))
    c.close(); return render_template("quotes/form.html",customers=cs,projects=ps)
@app.route("/quotes/<int:quote_id>")
def quote_detail(quote_id):
    c=get_connection(); q=c.execute("SELECT q.*,c.name customer_name,c.phone,c.email,c.category,p.project_name FROM quotes q JOIN customers c ON c.id=q.customer_id LEFT JOIN projects p ON p.id=q.project_id WHERE q.id=?",(quote_id,)).fetchone()
    if not q:c.close();abort(404)
    items=c.execute("SELECT * FROM quote_items WHERE quote_id=? ORDER BY sort_order,id",(quote_id,)).fetchall(); total=sum(float(x["subtotal"] or 0) for x in items); c.close(); return render_template("quotes/detail.html",quote=q,items=items,total=total)
@app.route("/quotes/<int:quote_id>/status",methods=["POST"])
def quote_status(quote_id):
    s=request.form.get("status","報價中")
    if s not in QUOTE_STATUSES:abort(400)
    c=get_connection(); c.execute("UPDATE quotes SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",(s,quote_id)); c.commit(); c.close(); return redirect(url_for("quote_detail",quote_id=quote_id))
@app.route("/projects")
def projects():
    c=get_connection(); rows=c.execute("SELECT p.*,c.name customer_name,(SELECT COUNT(*) FROM quotes q WHERE q.project_id=p.id) quote_count FROM projects p JOIN customers c ON c.id=p.customer_id ORDER BY p.id DESC").fetchall(); c.close(); return render_template("projects/list.html",projects=rows)
@app.route("/projects/new",methods=["GET","POST"])
def project_new():
    c=get_connection(); cs=c.execute("SELECT id,name,category FROM customers WHERE is_active=1 ORDER BY name").fetchall()
    if request.method=="POST":
        cid=request.form.get("customer_id"); name=request.form.get("project_name","").strip()
        if not cid or not name:c.close();flash("客戶與專案名稱皆為必填。","error");return render_template("projects/detail.html",project=None,quotes=[],customers=cs)
        cur=c.execute("INSERT INTO projects(customer_id,project_name,status,note) VALUES(?,?,?,?)",(int(cid),name,request.form.get("status","進行中"),request.form.get("note","").strip())); c.commit(); pid=cur.lastrowid;c.close();return redirect(url_for("project_detail",project_id=pid))
    c.close();return render_template("projects/detail.html",project=None,quotes=[],customers=cs)
@app.route("/projects/<int:project_id>")
def project_detail(project_id):
    c=get_connection();p=c.execute("SELECT p.*,c.name customer_name FROM projects p JOIN customers c ON c.id=p.customer_id WHERE p.id=?",(project_id,)).fetchone()
    if not p:c.close();abort(404)
    qs=c.execute("SELECT id,quote_number,status,created_at FROM quotes WHERE project_id=? ORDER BY id DESC",(project_id,)).fetchall();c.close();return render_template("projects/detail.html",project=p,quotes=qs,customers=[])
@app.route("/projects/<int:project_id>/edit",methods=["POST"])
def project_edit(project_id):
    c=get_connection();c.execute("UPDATE projects SET project_name=?,status=?,note=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",(request.form.get("project_name","").strip(),request.form.get("status","進行中"),request.form.get("note","").strip(),project_id));c.commit();c.close();return redirect(url_for("project_detail",project_id=project_id))
if __name__=="__main__":init_database();app.run(host="0.0.0.0",port=5000,debug=True)
