from pathlib import Path
import sqlite3
BASE_DIR=Path(__file__).resolve().parent.parent
DATABASE_DIR=BASE_DIR/"database"
DATABASE_PATH=DATABASE_DIR/"printshop.db"
def get_connection():
    DATABASE_DIR.mkdir(parents=True,exist_ok=True)
    c=sqlite3.connect(DATABASE_PATH); c.row_factory=sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON"); return c
def init_database():
    c=get_connection()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT DEFAULT '',email TEXT DEFAULT '',address TEXT DEFAULT '',category TEXT NOT NULL DEFAULT '一般',note TEXT DEFAULT '',is_active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS projects(id INTEGER PRIMARY KEY AUTOINCREMENT,customer_id INTEGER NOT NULL,project_name TEXT NOT NULL,status TEXT NOT NULL DEFAULT '進行中',note TEXT DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(customer_id) REFERENCES customers(id));
    CREATE TABLE IF NOT EXISTS quotes(id INTEGER PRIMARY KEY AUTOINCREMENT,quote_number TEXT NOT NULL UNIQUE,customer_id INTEGER NOT NULL,project_id INTEGER,mode TEXT NOT NULL DEFAULT 'normal',status TEXT NOT NULL DEFAULT '報價中',note TEXT DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(customer_id) REFERENCES customers(id),FOREIGN KEY(project_id) REFERENCES projects(id));
    CREATE TABLE IF NOT EXISTS quote_items(id INTEGER PRIMARY KEY AUTOINCREMENT,quote_id INTEGER NOT NULL,product_name TEXT NOT NULL,material TEXT DEFAULT '',size TEXT DEFAULT '',finishing TEXT DEFAULT '',quantity REAL NOT NULL DEFAULT 0,unit TEXT DEFAULT '',unit_price REAL NOT NULL DEFAULT 0,subtotal REAL NOT NULL DEFAULT 0,sort_order INTEGER NOT NULL DEFAULT 0,FOREIGN KEY(quote_id) REFERENCES quotes(id) ON DELETE CASCADE);
    CREATE INDEX IF NOT EXISTS idx_customers_name ON customers(name);
    CREATE INDEX IF NOT EXISTS idx_projects_customer ON projects(customer_id);
    CREATE INDEX IF NOT EXISTS idx_quotes_customer ON quotes(customer_id);
    CREATE INDEX IF NOT EXISTS idx_quotes_project ON quotes(project_id);
    CREATE INDEX IF NOT EXISTS idx_quote_items_quote ON quote_items(quote_id);
    """); c.commit(); c.close()
